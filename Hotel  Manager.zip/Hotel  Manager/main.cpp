#include <iostream>
#include <string>
#include <vector>
#include <stdint.h>

using namespace std;

class Room
{
private:
    uint8_t roomNumber;
    bool isBooked;
    bool isCleaning;

public:
    Room(uint8_t number)
    {
        roomNumber = number;
        isBooked = false;
        isCleaning = false;
    }
    uint8_t getRoomNumber() { return roomNumber; }
    bool isAvailable() { return !isBooked && isCleaning; }
    bool isBookedd() { return isBooked && !isCleaning; }
    void bookRoom() { isBooked = true; }
    void checkIn() { isCleaning = false; }
    void checkOut()
    {
        isCleaning = true;
        isBooked = false;
    }
};

class HotelManager
{
private:
    vector<Room> databaseRooms;

public:
    void addRooms(uint8_t numberOfRooms);
    void displayAvailableRooms();
    void bookRoom(uint8_t roomNumber);
    void checkIn(uint8_t roomNumber);
    void checkOut(uint8_t roomNumber);
};

void HotelManager::addRooms(uint8_t numberOfRooms)
{
    for (uint8_t i = 1; i <= numberOfRooms; ++i)
    {
        databaseRooms.push_back(Room(i));
    }
}

void HotelManager::displayAvailableRooms()
{
    cout << "Available Rooms:" << endl;
    for (auto &room : databaseRooms)
    {
        if (room.isAvailable())
        {
            cout << "Room " << (int)room.getRoomNumber() << " is available." << endl;
        }
    }
}

void HotelManager::bookRoom(uint8_t roomNumber)
{
    for (auto &room : databaseRooms)
    {
        if (room.getRoomNumber() == roomNumber && room.isAvailable())
        {
            room.bookRoom();
            cout << "Room " << (int)roomNumber << " has been booked." << endl;
            return;
        }
    }
    cout << "Room " << (int)roomNumber << " is not available for booking." << endl;
}

void HotelManager::checkIn(uint8_t roomNumber)
{
    for (auto &room : databaseRooms)
    {
        if (room.getRoomNumber() == roomNumber && room.isAvailable())
        {
            room.checkIn();
            cout << "Checked in to Room " << (int)roomNumber << "." << endl;
            return;
        }
    }
    cout << "Room " << (int)roomNumber << " check-in suscess." << endl;
}

void HotelManager::checkOut(uint8_t roomNumber)
{
    for (auto &room : databaseRooms)
    {
        if (room.getRoomNumber() == roomNumber && room.isBookedd())
        {
            room.checkOut();
            cout << "Checked out from Room " << (int)roomNumber << "." << endl;
            return;
        }
    }
    cout << "Room " << (int)roomNumber << "check-out suscess." << endl;
}
