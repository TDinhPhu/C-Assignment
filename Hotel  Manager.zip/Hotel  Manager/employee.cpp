#include <iostream>
#include <string>
#include <vector>

using namespace std;

typedef enum
{
    JANITOR,
    RECEPTIONIST,
    LAUDRY_STAFF,
    LUGGAGE_STAPP,
    GARDENER
} JobPosition;

typedef struct
{
    uint8_t day;
    uint8_t month;
    uint16_t year;
} typeDate;

typedef struct
{
    uint8_t second;
    uint8_t minute;
    uint8_t hour;
} typeTime;

typedef enum
{
    IN,
    OUT
} typeStatus;

typedef struct
{
    typeTime time;
    typeDate date;
} Schedule;

class User
{
private:
    string username;
    string password;

public:
    User(string username, string password);
    string getUsername() { return username; };
    bool authenticate(string inputPassword) { return inputPassword == password; };
};

User::User(string username, string password)
{
    this->username = username;
    this->password = password;
}

class Employee
{
    string name;
    string phoneNumber;
    JobPosition position;
    Schedule schedule;
    bool checkAuthenticate;
    User user;

public:
    Employee(string nameEmployee, string phoneNumberEmployee, JobPosition positionEmployee, Schedule scheduleEmployee, User userEmployee)
        : name(nameEmployee), phoneNumber(phoneNumberEmployee), position(positionEmployee), schedule(scheduleEmployee), checkAuthenticate(false), user(userEmployee) {}

    void getAuthenticate(string inputPassword);
    string getName();
    string getPhoneNumber();
    JobPosition getJobPosition();
    Schedule getSchedule();
    void setName(string newName) { name = newName; }
    void setPhoneNumber(string newPhoneNumber) { phoneNumber = newPhoneNumber; }
    void setPosition(JobPosition newPosition) { position = newPosition; }
    void setSchedule(Schedule newSchedule) { schedule = newSchedule; }
};

string Employee::getName()
{
    if (checkAuthenticate == true)
    {
        return this->name;
    }
}

string Employee::getPhoneNumber()
{
    {
        if (checkAuthenticate == true)
        {
            return this->phoneNumber;
        }
    }
}

JobPosition Employee::getJobPosition()
{
    {
        if (checkAuthenticate == true)
        {
            return this->position;
        }
    }
}

Schedule Employee::getSchedule()
{
    {
        if (checkAuthenticate == true)
        {
            return this->schedule;
        }
    }
}

void Employee::getAuthenticate(string inputPassword)
{
    if (user.authenticate(inputPassword) || inputPassword == "admin")
    {
        checkAuthenticate = true;
    }
    else
    {
        cout << "Password error!!\n";
    }
}

class EmployeeManager
{
private:
    vector<Employee> databaseEmployee;
public:
    void addEmployee();
    void editEmployee();
    void deleteEmployee();
    void displayEmployeeInformation();
};
void EmployeeManager::addEmployee()
{
    string name, phoneNumber, username, password;
    JobPosition position;
    Schedule schedule;

    cout << "Enter employee name: ";
    getline(cin, name);

    cout << "Enter employee phone number: ";
    getline(cin, phoneNumber);

    cout << "Enter employee position \n(0 Janitor, 1 Receptionist, 2 Laundry Staff, 3 Luggage Staff, 4 Gardener): ";
    int pos;
    cin >> pos;

    if (pos == 0)
    {
        position = JANITOR;
    }
    else if (pos == 1)
    {
        position = RECEPTIONIST;
    }
    else if (pos == 2)
    {
        position = LAUDRY_STAFF;
    }
    else if (pos == 3)
    {
        position = LUGGAGE_STAPP;
    }
    else if (pos == 4)
    {
        position = GARDENER;
    }
    else
    {
        cout << "Invalid position. Setting position to Janitor.\n";
        position = JANITOR;
    }

    cout << "Enter employee schedule (day month year hour minute second): ";
    cin >> schedule.date.day >> schedule.date.month >> schedule.date.year >> schedule.time.hour >> schedule.time.minute >> schedule.time.second;

    cout << "Enter employee username: ";
    cin.ignore();
    getline(cin, username);

    cout << "Enter employee password: ";
    getline(cin, password);

    User newUser(username, password);
    Employee newEmployee(name, phoneNumber, position, schedule, newUser);

    databaseEmployee.push_back(newEmployee);
}

void EmployeeManager::editEmployee()
{
    string searchName;
    cout << "Enter the name of the employee you want to edit: ";
    cin.ignore();
    getline(cin, searchName);

    for (auto &employee : databaseEmployee)
    {
        if (employee.getName() == searchName)
        {
            cout << "Editing employee: " << employee.getName() << endl;
            cout << "1. Edit name\n";
            cout << "2. Edit phone number\n";
            cout << "3. Edit position\n";
            cout << "4. Edit schedule\n";
            cout << "Choose the information to edit (1-4): ";
            int choice;
            cin >> choice;

            switch (choice)
            {
            case 1:
                cout << "Enter new name: ";
                cin.ignore();
                string newName;
                getline(cin, newName);
                employee.setName(newName);
                break;

            case 2:
                cout << "Enter new phone number: ";
                cin.ignore();
                string newPhoneNumber;
                getline(cin, newPhoneNumber);
                employee.setPhoneNumber(newPhoneNumber);
                break;

            case 3:
                cout << "Enter new position \n(0 Janitor, 1 Receptionist, 2 Laundry Staff, 3 Luggage Staff, 4 Gardener): ";
                int newPos;
                cin >> newPos;
                if (newPos >= 0 && newPos <= 4)
                {
                    employee.setPosition(static_cast<JobPosition>(newPos));
                }
                else
                {
                    cout << "Invalid position. Keeping the current position.\n";
                }
                break;

            case 4:
                cout << "Enter new schedule (day month year hour minute second): ";
                // cin >> employee.getSchedule().date.day >> employee.getSchedule().date.month >> employee.getSchedule().date.year >> employee.getSchedule().time.hour >> employee.getSchedule().time.minute >> employee.getSchedule().time.second;
                break;

            default:
                cout << "Invalid choice.\n";
                break;
            }

            cout << "Employee edited successfully.\n";
            return;
        }
    }
}
