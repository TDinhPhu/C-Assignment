#include <iostream>
#include <string>
#include <vector>
#include <stdint.h>

using namespace std;

typedef struct
{
    uint8_t day;
    uint8_t month;
    uint16_t year;
} typeDate;

typedef struct
{
    uint8_t second;
    uint8_t minute;
    uint8_t hour;
} typeTime;

typedef enum
{
    IN,
    OUT
} typeStatus;

typedef struct
{
    typeTime time;
    typeDate date;
    typeStatus status;
} bookingHistory;

class Customer
{
private:
    uint8_t idRoom;
    string name;
    string phoneNumber;
    string address;
    vector<bookingHistory> bookingHistorys;

public:
    Customer(string customerName, string customerPhone, string customerAddress)
        : name(customerName), phoneNumber(customerPhone), address(customerAddress){};
    string getName() { return name; };
    string getPhoneNumber();
    string getAddress();
    vector<bookingHistory> &getBookingHistory();
    void addBookingHistory(bookingHistory bookingDetails);
    void displayBookingHistory();
};

void Customer::addBookingHistory(bookingHistory bookingDetails)
{
    bookingHistorys.push_back(bookingDetails);
}
void Customer::displayBookingHistory()
{
    cout << "Booking History for Customer " << name << ":\n";
    for (const auto &history : bookingHistorys)
    {
        cout << "Date: " << (int)history.date.day << "/" << (int)history.date.month << "/" << history.date.year;
        cout << " Time: " << (int)history.time.hour << ":" << (int)history.time.minute << ":" << (int)history.time.second;
        cout << " Status: " << (history.status == IN ? "IN" : "OUT") << "\n";
    }
}
string Customer::getName()
{
    return name;
}

string Customer::getPhoneNumber()
{
    return phoneNumber;
}

string Customer::getAddress()
{
    return address;
}

vector<bookingHistory> &Customer::getBookingHistory()
{
    return bookingHistorys;
}


class CustomerManager
{
private:
    vector<Customer> databaseCustomers;

public:
    void addCustomer();
    void editCustomer();
    void deleteCustomer();
    void displayCustomerInfor();
};

void CustomerManager::addCustomer()
{
    string name, phone, address;
    cout << "Enter customer name: ";
    cin >> name;
    cout << "Enter customer phone: ";
    cin >> phone;
    cout << "Enter customer address: ";
    cin >> address;

    Customer newCustomer(name, phone, address);
    databaseCustomers.push_back(newCustomer);
    cout << "Customer added successfully.\n";
}

void CustomerManager::editCustomer()
{
    string name;
    cout << "Enter the name of the customer to edit: ";
    cin >> name;

    for (auto &customer : databaseCustomers)
    {
        if (customer.getName() == name)
        {
            string newName, newPhone, newAddress;
            cout << "Enter new name: ";
            cin >> newName;
            cout << "Enter new phone: ";
            cin >> newPhone;
            cout << "Enter new address: ";
            cin >> newAddress;

            customer = Customer(newName, newPhone, newAddress);
            cout << "Customer information updated successfully.\n";
            return;
        }
    }

    cout << "Customer not found.\n";
}

void CustomerManager::deleteCustomer()
{
    string name;
    cout << "Enter the name of the customer to delete: ";
    cin >> name;

    for (auto it = databaseCustomers.begin(); it != databaseCustomers.end(); ++it)
    {
        if (it->getName() == name)
        {
            databaseCustomers.erase(it);
            cout << "Customer deleted successfully.\n";
            return;
        }
    }

    cout << "Customer not found.\n";
}

void Customer::displayBookingHistory()
{
    if (bookingHistorys.empty())
    {
        cout << "No booking history.\n";
    }
    else
    {
        for (auto &booking : bookingHistorys)
        {
            cout << "  Date: ";
            if (booking.date.day < 10)
                cout << '0';
            cout << (int)booking.date.day << "/";

            if (booking.date.month < 10)
                cout << '0';
            cout << (int)booking.date.month << "/" << booking.date.year << " ";

            cout << "  Time: ";
            if (booking.time.hour < 10)
                cout << '0';
            cout << (int)booking.time.hour << ":";

            if (booking.time.minute < 10)
                cout << '0';
            cout << (int)booking.time.minute << ":";

            if (booking.time.second < 10)
                cout << '0';
            cout << (int)booking.time.second << " ";

            cout << "  Status: " << (booking.status == IN ? "IN" : "OUT") << endl;
        }
    }
}
